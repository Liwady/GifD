#import <CepheiPrefs/HBAboutListController.h>

static NSString *const VLYBundlesPath = @"/var/mobile/Library/Vitality/";

@interface VLYRootListController : HBAboutListController

@end
