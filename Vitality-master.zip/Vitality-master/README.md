# Vitality
Animated (Gif) Wallpapers on iOS. Minimal battery impact (hopefully)
